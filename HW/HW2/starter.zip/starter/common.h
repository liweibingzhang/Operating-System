// Height and width of the playing area.
#define GRID_SIZE 5
